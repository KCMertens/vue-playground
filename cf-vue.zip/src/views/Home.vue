<template>
    <div class="home">
        This is the home page component
    </div>
</template>

<script lang="ts">
import Vue from 'vue';

export default Vue.extend({
    name: 'home',
});
</script>
